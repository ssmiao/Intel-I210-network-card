## 3D模型说明:mask::mask::mask:  

### version ：0.0.2


-----------------------
|Author|MistyMoon|
|---|---
|E-mail|MistyMoonR@outlook.com

-----------------------
### 

OCP网卡+挡板 是完整STEP图纸

挡板V3.2(合适钣金件) 文件 不需要做任何修改可以直接找JS，建议最好自己检查。

V4 图纸修改说明：移动孔位 可以兼容PCB 0.1bate版本，同时添加散热孔(镂空)

增加半高挡板图纸(镂空)

![IMG](/3D_model/img/V3.2.jpg)
 
