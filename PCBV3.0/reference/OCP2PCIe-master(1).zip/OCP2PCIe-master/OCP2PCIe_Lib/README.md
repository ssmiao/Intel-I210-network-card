# OCP Public Lib

- OCP2PCIe_Lib.pretty  
封装库

- OCP2PCIe_Lib.lib  
符号库