# Pre-release
**预发行版**

尚未进行标准化规范  
Not standardized

具有SMBUS连接，在部分服务器主板上可能不稳定  
With SMBUS connection, may be unstable on some server motherboards