# V1.0 Beta ChangeLog

最后一个非标准版本  
Last non-standard design version

已删除SMBUS连接  
Delete SMBUS

细化了外框  
Modify the frame

添加了LOGO，刷新了版本号  
Added LOGO, refreshed version

接下来将优先建立OCP2PCIe Lib，并进行标准化重构  
In the next step, the OCP2PCIe Lib will be established first, and standardized reconstruction will be performed.
