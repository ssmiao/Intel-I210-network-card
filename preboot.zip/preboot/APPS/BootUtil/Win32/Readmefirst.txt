Installing this utility will overwrite some files required for Intel(R) PROSet for Windows Device Manager. This may result in system bug checks or loss of functionality when using Intel(R) PROSet or other tools using the same driver. Please uninstall Intel PROSet before installing this utility.

Note that re-installing PROSet later on could render this tool useless.